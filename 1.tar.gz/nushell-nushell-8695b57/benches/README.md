# Criterion benchmarks

These are benchmarks using [Criterion](https://github.com/bheisler/criterion.rs), a microbenchmarking tool for Rust.

Run all benchmarks with `cargo bench`

Or run individual benchmarks like `cargo bench -- <regex>` e.g. `cargo bench -- parse`