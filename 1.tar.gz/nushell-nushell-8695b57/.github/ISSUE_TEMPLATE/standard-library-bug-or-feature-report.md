---
name: standard library bug or feature report
about: Used to submit issues related to the nu standard library
title: ''
labels: ['needs-triage', 'std-library']
assignees: ''

---

**Describe the bug or feature**
A clear and concise description of what the bug is.
