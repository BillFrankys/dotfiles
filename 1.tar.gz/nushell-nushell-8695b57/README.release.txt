To use Nu plugins, use the register command to tell Nu where to find the plugin. For example:

> register ./nu_plugin_query
